DROP DATABASE IF EXISTS  just_tech_news_db;

CREATE DATABASE  just_tech_news_db;